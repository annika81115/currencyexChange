Nice READ.me

second repo with scraper: https://github.com/MuffinCPT/Scraper-SWE-II
